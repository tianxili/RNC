library(Matrix)


logit.net <- function(A,lambda,Y,X=NULL,max.iter=500,thr=1e-7,init=NULL,theta=0.05,cv=NULL,cv.seed=999,verbose=FALSE){
    #print(paste("max iteration number:",max.iter))
    n <- nrow(A)
    if(is.null(X)){
    	    p <- 0
    	}else{
    		p <- ncol(X)
    		}
    if(is.null(init)){

        alpha.null <- rep(0,n)
        beta.null <- rep(0,p)
        beta.tilde.null <- matrix(c(alpha.null,beta.null),ncol=1)
    }else{
        beta.tilde.null <- matrix(init,ncol=1)
    }

    X.tilde <- cbind(diag(rep(1,n)),X)
    iter <- 0
    err <- 100

    D <- diag(rowSums(A))

        M.sub <- lambda*((D - A) + theta*diag(rep(1,n)))

    M <- matrix(0,nrow=n+p,ncol=n+p)
    M[1:n,1:n] <- M.sub


    while((iter < max.iter) && (err > thr)){
    	iter <- iter + 1
    	eta.old <- X.tilde %*% beta.tilde.null
    	    p.old <- as.numeric(exp(eta.old)/(1+exp(eta.old)))
            p.old[is.na(p.old)] <- 1
            p.old.smooth <- p.old
            need.smooth <- which(abs(abs(p.old-0.5)-0.5)<1e-5)
            p.old.smooth[need.smooth] <- 0.5 + 0.5*sign(p.old.smooth[need.smooth]-0.5)-(1e-5)*sign(p.old.smooth[need.smooth]-0.5)
    	    w.diag <- p.old.smooth*(1-p.old.smooth)
    	    W.mat <- diag(w.diag)
    	    z <- eta.old + (Y-p.old.smooth)/w.diag
    	Project.mat <- solve((M + t(X.tilde)%*%W.mat%*%X.tilde/n),t(X.tilde)%*%W.mat)/n
    	    #M.mat <- Matrix(M + t(X.tilde)%*%W.mat%*%X.tilde/n,sparse=TRUE)
    	    #Project.mat <- solve(M.mat,Matrix(t(X.tilde)%*%W.mat))/n
    	    beta.tilde <- Project.mat %*%z
    	    err <- sqrt(sum((beta.tilde-beta.tilde.null)^2))
    	    beta.tilde.null <- beta.tilde
    	    alpha <- beta.tilde[1:n]
    	    beta <- beta.tilde[-(1:n)]
    	    if(is.null(X)){
                eta.fitted <- alpha
            }else{
                eta.fitted <- alpha + X%*%matrix(beta,ncol=1)
            }
            p.fitted <- exp(eta.fitted)/(1+exp(eta.fitted))
            p.fitted[p.fitted<1e-6] <- 1e-6
            p.fitted[p.fitted>1- 1e-6] <- 1- 1e-6
            current.dev <- -sum(Y*log(p.fitted)) - sum((1-Y)*log(1-p.fitted)) 
            current.cohesion <- matrix(alpha,nrow=1)%*%(D-A)%*%matrix(alpha,ncol=1)
            if(verbose) print(c(current.dev,current.cohesion,current.dev+lambda*current.cohesion))
            #print(beta.tilde)
    }
    alpha <- beta.tilde[1:n]
    beta <- beta.tilde[-(1:n)]
    cv.dev <- NULL
    if(is.null(X)){
        eta.fitted <- alpha
    }else{
        eta.fitted <- alpha + X%*%matrix(beta,ncol=1)
    }
    p.fitted <- exp(eta.fitted)/(1+exp(eta.fitted))
    df <- sum(diag(X.tilde%*%Project.mat))

    if(!is.null(cv)){
        if(is.null(X)){

        K <- cv
        set.seed(500)
        cv.dev <- 0
        cv.order <- sample(n,size=n)
        cv.index <- 1:n
        cv.index[cv.order] <- 1:K
        for(k in 1:K){
            current.index <- which(cv.index!=k)
            valid.index <- which(cv.index==k)
            s.A <- A[current.index,current.index]
            cv.logit.net <- logit.net(X=NULL,Y=Y[current.index],A=s.A,lambda=lambda,theta=theta,max.iter=max.iter,thr=thr)
            n.valid <- length(valid.index)
            valid.alpha <- rep(0,n.valid)
            for(v in 1:n.valid){
                valid.id <- valid.index[v]
                valid.alpha[v] <- sum(A[valid.id,current.index]*cv.logit.net$alpha)/(sum(A[valid.id,current.index])+theta+1e-5)
            }
            valid.eta <- valid.alpha
            valid.p <- exp(valid.eta)/(1+exp(valid.eta))
            valid.p.smooth <- valid.p
            need.smooth <- which(abs(abs(valid.p-0.5)-0.5)<1e-5)
            valid.p.smooth[need.smooth] <- 0.5 + 0.5*sign(valid.p.smooth[need.smooth]-0.5)-(1e-5)*sign(valid.p.smooth[need.smooth]-0.5)
            #print(valid.p)
            #print(- sum(Y[valid.index]*log(valid.p.smooth)) - sum((1-Y[valid.index])*log(1-valid.p.smooth)))
            cv.dev <- cv.dev - sum(Y[valid.index]*log(valid.p.smooth)) - sum((1-Y[valid.index])*log(1-valid.p.smooth))
        }

        }else{
        K <- cv
        set.seed(500)
        cv.dev <- 0
        cv.order <- sample(n,size=n)
        cv.index <- 1:n
        cv.index[cv.order] <- 1:K
        for(k in 1:K){
            current.index <- which(cv.index!=k)
            valid.index <- which(cv.index==k)
            s.A <- A[current.index,current.index]
            cv.logit.net <- logit.net(X=matrix(X[current.index,],ncol=ncol(X)),Y=Y[current.index],A=s.A,lambda=lambda,theta=theta,max.iter=max.iter,thr=thr,init=init[-valid.index])
            n.valid <- length(valid.index)
            valid.alpha <- rep(0,n.valid)
            for(v in 1:n.valid){
                valid.id <- valid.index[v]
                valid.alpha[v] <- sum(A[valid.id,current.index]*cv.logit.net$alpha)/(sum(A[valid.id,current.index])+theta+1e-6)
            }
            valid.eta <- valid.alpha + X[valid.index,]%*%matrix(cv.logit.net$beta,ncol=1)
            valid.p <- exp(valid.eta)/(1+exp(valid.eta))
            valid.p[valid.p<1e-6] <- 1e-6
            valid.p[valid.p>(1-1e-6)] <- 1-1e-6
            cv.dev <- cv.dev - sum(Y[valid.index]*log(valid.p)) - sum((1-Y[valid.index])*log(1-valid.p))
        }
    }
    }


    return(list(alpha=alpha,beta=beta,err=err,iter=iter,df=df,cv.dev=cv.dev,fitted=p.fitted))
}


