This folder contains the code for the simulation part of paper
Regression with network cohesion
by Tianxi Li, Elizaveta Levina, Ji Zhu

The file FinalLMEvaluation-HasBetween.R is the script for simulation
evaluation of linear regression with network cohesion.

The file FinalLogisticEvaluation-HasBetween.R is the script for simulation
evaluation of logistic regression with network cohesion.

The file NetLogitFunc.R is the implementation of logistic RNC method.

In the paper, the data examples are on AddHealth data. Since the data
is not for public use, we do not include the code here. However, the
implementation of Cox's RNC is included for independent interests in the file
CoxRNC.R

All these scripts are written in the most straightforward manner by
R. The current implementations of Logistic-RNC and Cox-RNC are still not very efficient. We will publish an R package with more efficient implementations of all RNC methods soon.
