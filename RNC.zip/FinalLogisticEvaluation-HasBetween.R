rm(list=ls())
require(doParallel)


library(plyr)
library(igraph)


BlockGen <- function(V,K,inter.p=0.8,between.p=0.2){
    nodes <- rep(1:V)
    membership <- sample(K,size=V,replace=TRUE)
    node1 <- node2 <- NULL
    for(i in 1:(V-1)){
        for(j in (i+1):V){
            if(membership[i]==membership[j]){
                connect <- rbinom(1,1,inter.p)
                if(connect==1){
                    node1 <- c(node1,i)
                    node2 <- c(node2,j)
                }
            }else{
                connect <- rbinom(1,1,between.p)
                if(connect==1){
                    node1 <- c(node1,i)
                    node2 <- c(node2,j)
                }

            }
        }
    }
    EdgeList <- data.frame(node1=node1,node2=node2)
    return(list(Edge=EdgeList,Block=membership))
}

AlphaGen.from.Block <- function(Block,s=4,scale=1){
    K <- length(unique(Block))
    V <- length(Block)
    #scale <- s
    centroids <- seq(-scale,scale,length.out=K)
    alpha <- rep(0,V)
    for(v in 1:V){
        alpha[v] <- rnorm(1,mean=centroids[Block[v]],sd=s)
    }
#    centroids <- centroids - mean(alpha)
#    alpha <- alpha - mean(alpha)
#    centroids <- centroids/(max(alpha)-min(alpha))*2*scale
#    alpha <- alpha/(max(alpha)-min(alpha))*2*scale
    shift <- mean(alpha)
    alpha <- alpha - shift
    centroids <- centroids - shift
    return(list(alpha=alpha,centroids=centroids))
}



Bernoulli.Gen <- function(alpha,p,beta.given=NULL){
    if(is.null(beta.given)){
    beta <- matrix(rnorm(p,mean=1),ncol=1)
    n <- length(alpha)
    X <- matrix(rnorm(n*p),ncol=p)
    X <- scale(X,center=TRUE,scale=FALSE)
    eta <- X%*%beta + alpha
    p.eta <- exp(eta)/(1+exp(eta))
    Y <- matrix(rep(0,n),ncol=1)
    for(i in 1:n) Y[i] <- sample(c(0,1),size=1,prob=c(1-p.eta[i],p.eta[i]))
    }else{
      beta <- matrix(beta.given,ncol=1)
    n <- length(alpha)
    X <- matrix(rnorm(n*p),ncol=p)
    X <- scale(X,center=TRUE,scale=FALSE)
    eta <- X%*%beta + alpha
    p.eta <- exp(eta)/(1+exp(eta))
    Y <- matrix(rep(0,n),ncol=1)
    for(i in 1:n) Y[i] <- sample(c(0,1),size=1,prob=c(1-p.eta[i],p.eta[i]))
    }
    return(list(X=X,Y=Y,alpha=alpha,beta=beta,prob=p.eta))
}

source("NetLogitFunc.R")

registerDoParallel(cores=11)
s.seq <- seq(0,3,by=0.3)
p.x <- 2
set.seed(99)
beta.init <- rnorm(p.x)+1



r <- foreach(ss=1:11) %dopar%{

s.value <- s.seq[ss]

net.dev <- linear.dev <- net.dev.normal <- net.MSE.normal <- net.alpha.MSE.normal <- net.beta.MSE.normal <- linear.beta.MSE <- linear.alpha.MSE <- net.beta.MSE <- net.alpha.MSE <- linear.MSE <- net.MSE <- rep(0,300)

for(i in 1:300){
set.seed(i+100)
block.g <- BlockGen(330,K=3,inter.p=0.5,between.p=0.1)
true.alpha <- AlphaGen.from.Block(block.g$Block,s=s.value,scale=1)
dd <- Bernoulli.Gen(true.alpha$alpha,p=2,beta.given=beta.init)

X <- dd$X
Y <- dd$Y
g <- graph.data.frame(block.g$Edge,directed=FALSE)
Adj <- as.matrix(get.adjacency(g))

new.index <- as.numeric(V(g)$name)

X <- matrix(dd$X[new.index,],ncol=2)
Y <- dd$Y[new.index]
prob <- dd$prob[new.index]

test.X <- X[301:330,]
test.Y <- Y[301:330]
test.Adj <- Adj

X <- X[1:300,]
Y <- Y[1:300]
prob <- prob[1:300]
Adj <- Adj[1:300,1:300]

model.df <- data.frame(X)
model.df$Y <- Y

logit <- glm(Y~.,family="binomial",data=model.df)

lambda.seq <- exp(seq(log(2),log(0.0001),length.out=50))
cv.seq <- matrix(0,nrow=50,ncol=5)
theta.seq <- c(exp(seq(log(1),log(0.001),length.out=4)),0)



for(jj in 1:5){
    
    theta <- theta.seq[jj]
    for(ii in 1:50){
    if(ii ==1) init.est <- NULL
    lambda <- lambda.seq[ii]
    m1 <- logit.net(A=Adj,lambda=lambda,Y=Y,X=X,theta=theta,cv=10,init=init.est)
    #m1 <- logit.net(A=Adj,lambda=lambda,Y=Y,X=X,theta=theta,cv=10)
    cv.seq[ii,jj] <- m1$cv.dev
    init.est <- c(m1$alpha,m1$beta)
}
}
opt.pos <- which(cv.seq == min(cv.seq), arr.ind = TRUE)
opt.lambda <- lambda.seq[opt.pos[1,1]]
opt.theta <- theta.seq[opt.pos[1,2]]

m1 <- logit.net(A=Adj,lambda=opt.lambda,Y=Y,X=X,theta=opt.theta)


linear.test <- predict(logit,newdata=data.frame(test.X),type="response")
linear.dev[i] <- -sum(test.Y*log(linear.test)) - sum((1-test.Y)*log(1-linear.test))


n.test <- 30
test.alpha <- rep(0,n.test)
for(v in 1:n.test){
     valid.id <- 100+v
     test.alpha[v] <- sum(test.Adj[valid.id,1:100]*m1$alpha)/(sum(test.Adj[valid.id,1:100])+1e-6)
     }
     test.eta <- test.alpha + test.X%*%matrix(m1$beta,ncol=1)
     net.test.p <- exp(test.eta)/(1+exp(test.eta))
net.dev[i] <- -sum(test.Y*log(net.test.p)) - sum((1-test.Y)*log(1-net.test.p))




linear.MSE[i] <- sum((prob-logit$fitted)^2)
net.MSE[i] <- sum((prob-m1$fitted)^2)
net.beta.MSE[i] <- sum((m1$beta-dd$beta)^2)
linear.beta.MSE[i] <- sum((logit$coef[2:3]-dd$beta)^2)
net.alpha.MSE[i] <- sum((m1$alpha-dd$alpha[1:100])^2)
linear.alpha.MSE[i] <- sum((logit$coef[1]-dd$alpha[1:100])^2)

opt.lambda.normal <- lambda.seq[which.min(cv.seq[,5])]

m2 <- logit.net(A=Adj,lambda=opt.lambda.normal,Y=Y,X=X,theta=0)

net.MSE.normal[i] <- sum((prob-m2$fitted)^2)
net.beta.MSE.normal[i] <- sum((m2$beta-dd$beta)^2)
net.alpha.MSE.normal[i] <- sum((m2$alpha-dd$alpha[1:100])^2)

test.alpha <- rep(0,n.test)
for(v in 1:n.test){
     valid.id <- 100+v
     test.alpha[v] <- sum(test.Adj[valid.id,1:100]*m2$alpha)/(sum(test.Adj[valid.id,1:100])+1e-6)
     }
     test.eta <- test.alpha + test.X%*%matrix(m2$beta,ncol=1)
     net.normal.test.p <- exp(test.eta)/(1+exp(test.eta))
net.dev.normal[i] <- -sum(test.Y*log(net.normal.test.p)) - sum((1-test.Y)*log(1-net.normal.test.p))

}



tmp <- list(linear.beta.MSE=linear.beta.MSE, linear.alpha.MSE=linear.alpha.MSE, net.beta.MSE=net.beta.MSE, net.alpha.MSE=net.alpha.MSE, linear.MSE=linear.MSE, net.MSE=net.MSE,net.MSE.normal=net.MSE.normal,net.beta.MSE.normal=net.beta.MSE.normal,net.alpha.MSE.normal=net.alpha.MSE.normal,linear.dev=linear.dev,net.dev=net.dev,net.dev.normal=net.dev.normal)

}

save(r,file="FinalRegressionLogisticEvaluation-HasBetweenBlockGraph-withRidge.Rda")