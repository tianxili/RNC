rm(list=ls())
require(doParallel)


library(plyr)
library(igraph)


BlockGen <- function(V,K,inter.p=0.8,between.p=0.2){
    nodes <- rep(1:V)
    membership <- sample(K,size=V,replace=TRUE)
    node1 <- node2 <- NULL
    for(i in 1:(V-1)){
        for(j in (i+1):V){
            if(membership[i]==membership[j]){
                connect <- rbinom(1,1,inter.p)
                if(connect==1){
                    node1 <- c(node1,i)
                    node2 <- c(node2,j)
                }
            }else{
                connect <- rbinom(1,1,between.p)
                if(connect==1){
                    node1 <- c(node1,i)
                    node2 <- c(node2,j)
                }

            }
        }
    }
    EdgeList <- data.frame(node1=node1,node2=node2)
    return(list(Edge=EdgeList,Block=membership))
}

AlphaGen.from.Block <- function(Block,s=4,scale=1){
    K <- length(unique(Block))
    V <- length(Block)
    #scale <- s
    centroids <- seq(-scale,scale,length.out=K)
    alpha <- rep(0,V)
    for(v in 1:V){
        alpha[v] <- rnorm(1,mean=centroids[Block[v]],sd=s)
    }
#    centroids <- centroids - mean(alpha)
#    alpha <- alpha - mean(alpha)
#    centroids <- centroids/(max(alpha)-min(alpha))*2*scale
#    alpha <- alpha/(max(alpha)-min(alpha))*2*scale
    shift <- mean(alpha)
    alpha <- alpha - shift
    centroids <- centroids - shift
    return(list(alpha=alpha,centroids=centroids))
}



Regression.Gen <- function(alpha,p,sigma=1,beta.given=NULL){
    if(is.null(beta.given)){
    beta <- matrix(rnorm(p,mean=1),ncol=1)
    n <- length(alpha)
    X <- matrix(rnorm(n*p),ncol=p)
    X <- scale(X,center=TRUE,scale=FALSE)
    EY <- X%*%beta + alpha
    Y <- EY + rnorm(n)*sigma
    }else{
      beta <- matrix(beta.given,ncol=1)
    n <- length(alpha)
    X <- matrix(rnorm(n*p),ncol=p)
    X <- scale(X,center=TRUE,scale=FALSE)
    EY <- X%*%beta + alpha
    Y <- EY + rnorm(n)*sigma

    }
    return(list(X=X,Y=Y,alpha=alpha,beta=beta,EY=EY))
}



lm.net <- function(X,Y,Adj,lambda,theta,cv=NULL,normal=FALSE){
    n <- nrow(X)
    p <- ncol(X)
    Y <- matrix(Y,ncol=1)
    D <- diag(rowSums(Adj))
    L <- D - Adj
    Omega <- lambda*(L + theta*diag(rep(1,n)))
    if(normal){
         d.seq <- rowSums(Adj)
         dd <- diag(1/sqrt(d.seq + theta*rep(1,n)))
         Omega <- lambda * dd%*%(L + theta*diag(rep(1,n)))%*%dd
    }
    X.tilde <- cbind(diag(rep(1,n)),X)
    M <- matrix(0,n+p,n+p)
    M[1:n,1:n] <- Omega
    alpha.beta <- solve(M + t(X.tilde)%*%X.tilde/n,t(X.tilde)%*%Y)/n
    alpha <- alpha.beta[1:n]
    beta <- alpha.beta[-(1:n)]
    cv.MSE <- 0
    if(!is.null(cv)){
        K <- cv
        set.seed(500)
        cv.order <- sample(n,size=n)
        cv.index <- 1:n
        cv.index[cv.order] <- 1:K
        for(k in 1:K){
            current.index <- which(cv.index!=k)
            valid.index <- which(cv.index==k)
            s.A <- Adj[current.index,current.index]
            cv.lm.net <- lm.net(X=matrix(X[current.index,],ncol=ncol(X)),Y=Y[current.index],Adj=s.A,lambda=lambda,theta=theta)
            n.valid <- length(valid.index)
            valid.alpha <- rep(0,n.valid)
            for(v in 1:n.valid){
                valid.id <- valid.index[v]
                valid.alpha[v] <- sum(Adj[valid.id,current.index]*cv.lm.net$alpha)/sum(Adj[valid.id,current.index])
            }
            valid.y <- valid.alpha + X[valid.index,]%*%matrix(cv.lm.net$beta,ncol=1)
            cv.MSE <- cv.MSE + mean((valid.y-Y[valid.index])^2)
        }
        cv.MSE <- cv.MSE/K
    }
    return(list(alpha=alpha,beta=beta,cv.MSE=cv.MSE))
}


intercept.net <- function(Y,Adj,lambda,theta,cv=NULL){
    n <- length(Y)
    Y <- matrix(Y,ncol=1)
    D <- diag(rowSums(Adj))
    L <- D - Adj
    Omega <- lambda*(L + theta*diag(rep(1,n)))
    M <- matrix(0,n,n)
    M[1:n,1:n] <- Omega
    X.tilde <- diag(rep(1,n))
    alpha.beta <- solve(M + t(X.tilde)%*%X.tilde/n,t(X.tilde)%*%Y)/n
    alpha <- alpha.beta[1:n]
    beta <- NULL
    cv.MSE <- 0
    train.err <- sum((alpha - Y)^2)
    if(!is.null(cv)){
        K <- cv
        set.seed(500)
        cv.order <- sample(n,size=n)
        cv.index <- 1:n
        cv.index[cv.order] <- 1:K
        for(k in 1:K){
            current.index <- which(cv.index!=k)
            valid.index <- which(cv.index==k)
            s.A <- Adj[current.index,current.index]
            s.Y <- Y[current.index]
            cv.lm.net <- intercept.net(Y=s.Y,Adj=s.A,lambda=lambda,theta=theta)
            n.valid <- length(valid.index)
            valid.alpha <- rep(0,n.valid)
            for(v in 1:n.valid){
                valid.id <- valid.index[v]
                valid.alpha[v] <- sum(Adj[valid.index,current.index]*cv.lm.net$alpha)/(sum(Adj[valid.index,current.index])+theta)
            }
            valid.y <- valid.alpha
            #print(valid.alpha)
            #print(Y[valid.index])
            cv.MSE <- cv.MSE + mean((valid.y-Y[valid.index])^2)
            #print(cv.MSE)

        }
        cv.MSE <- cv.MSE/K
    }
    return(list(alpha=alpha,beta=beta,cv.MSE=cv.MSE,train.err=train.err))
}

registerDoParallel(cores=20)
s.seq <- c(seq(0,2,by=0.2),seq(3,15,by=1.5))
p.x <- 2
set.seed(99)
beta.init <- rnorm(p.x)+1
r <- foreach(ss=1:20) %dopar%{

s.value <- s.seq[ss]

PE.MSE.net <- PE.MSE.linear <- PE.MSE.net.normal <- alpha.MSE.net.normal <- beta.normal <- beta.bias.normal <- beta.MSE.normal <- beta.linear <- beta.net <- beta.bias.linear <- beta.bias.net <- alpha.MSE.linear <- alpha.MSE.net <- beta.MSE.linear <- beta.MSE.net <- rep(0,100)
for(m in 1:100){
    set.seed(m+100)
block.g <- BlockGen(300,K=3,inter.p=0.5,between.p=0.1)
true.alpha <- AlphaGen.from.Block(block.g$Block,s=s.value,scale=1)
dd <- Regression.Gen(true.alpha$alpha,p=p.x,sigma=0.5,beta.given=beta.init)
g <- graph.data.frame(block.g$Edge,directed=FALSE)
Adj <- get.adjacency(g)

new.index <- as.numeric(V(g)$name)

X <- matrix(dd$X[new.index,],ncol=p.x)
Y <- dd$Y[new.index]
EY <- dd$EY[new.index]
trueAlpha <- dd$alpha[new.index]
linear <- lm(dd$Y~dd$X)
MSE.seq <- matrix(0,nrow=50,ncol=10)
lambda.seq <- exp(seq(log(10),log(0.00001),length.out=50))
theta.seq <- c(exp(seq(log(1),log(0.00001),length.out=9)),0)

for(i in 1:50){
    lambda <- lambda.seq[i]
    for(j in 1:10){
    theta <- theta.seq[j]
    tmp.t <- lm.net(X=X,Y=Y,Adj=as.matrix(Adj),lambda=lambda,theta=theta,cv=10,normal=FALSE)
    MSE.seq[i,j] <- tmp.t$cv.MSE
}
}
opt.pos <- which(MSE.seq == min(MSE.seq), arr.ind = TRUE)
opt.lambda <- lambda.seq[opt.pos[1,1]]
opt.theta <- theta.seq[opt.pos[1,2]]
opt.model <- lm.net(Y=Y,X=X,Adj=as.matrix(Adj),lambda=opt.lambda,theta=opt.theta,cv=10,normal=FALSE)

beta.err.linear <- linear$coef[2:(p.x+1)] - dd$beta
beta.err.net <- opt.model$beta - dd$beta

alpha.err.linear <- trueAlpha - linear$coef[1]
alpha.err.net <- trueAlpha - opt.model$alpha

alpha.MSE.linear[m] <- sum(alpha.err.linear^2)
alpha.MSE.net[m] <- sum(alpha.err.net^2)

PE.err.linear <- EY - linear$fitted
PE.err.net <- EY - X%*%matrix(opt.model$beta,ncol=1) - opt.model$alpha


beta.MSE.linear[m] <- sum(beta.err.linear^2)
beta.MSE.net[m] <- sum(beta.err.net^2)

beta.bias.linear[m] <- sum(beta.err.linear)
beta.bias.net[m] <- sum(beta.err.net)

beta.linear[m] <- linear$coef[2]
beta.net[m] <- opt.model$beta[1]


PE.MSE.linear[m] <- sum(PE.err.linear^2)
PE.MSE.net[m] <- sum(PE.err.net^2)

#normal.MSE.seq <- rep(0,50)
#for(i in 1:50){
 #   lambda <- lambda.seq[i]
  #  tmp.t <- lm.net(X=X,Y=Y,Adj=as.matrix(Adj),lambda=lambda,theta=0,cv=10,normal=FALSE)
   # normal.MSE.seq[i] <- tmp.t$cv.MSE
#}
opt.lambda <- lambda.seq[which.min(MSE.seq[,10])]
opt.model <- lm.net(Y=Y,X=X,Adj=as.matrix(Adj),lambda=opt.lambda,theta=0,normal=FALSE)


beta.err.normal <- opt.model$beta - dd$beta

PE.err.normal <- EY - X%*%matrix(opt.model$beta,ncol=1) - opt.model$alpha

beta.MSE.normal[m] <- sum(beta.err.normal^2)

beta.bias.normal[m] <- sum(beta.err.normal)

beta.normal[m] <- opt.model$beta[1]

alpha.err.net.normal <- trueAlpha - opt.model$alpha


alpha.MSE.net.normal[m] <- sum(alpha.err.net.normal^2)
PE.MSE.net.normal[m] <- sum(PE.err.normal^2)

}
tmp <- list(alpha.MSE.linear=alpha.MSE.linear,alpha.MSE.net=alpha.MSE.net,beta.MSE.linear=beta.MSE.linear,beta.MSE.net=beta.MSE.net,beta.bias.linear=beta.bias.linear,beta.bias.net=beta.bias.net,beta.linear=beta.linear,beta.net=beta.net,beta.MSE.normal=beta.MSE.normal,beta.bias.normal=beta.bias.normal,beta.normal=beta.normal,alpha.MSE.net.normal=alpha.MSE.net.normal,PE.MSE.linear=PE.MSE.linear,PE.MSE.net=PE.MSE.net,PE.MSE.net.normal=PE.MSE.net.normal)
}

save(r,file="FinalRegressionEvaluation-HasBetweenBlockGraph.Rda")