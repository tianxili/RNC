library(survival)
SurvNetSmooth <- function(g,kernel="Gaussian",h=1,dt){
    v.names <- V(g)$name
    DistMat <- shortest.paths(g)
    KernelMat <- dnorm(DistMat,mean=0,sd=sqrt(h))
    n <- length(V(g))
    surv.obj <- Surv(time=dt$y,event=dt$delta)
    BetaMat <- NULL
    for(v in 1:n){
        tmp.exp <- survreg(surv.obj~.-y-delta-1,data=dt,weights=KernelMat[v,],dist="exponential")
        BetaMat <- rbind(BetaMat,tmp.exp$coef)
    }
    return(BetaMat)
}

SurvNetSmooth.exp.noCov <- function(g,kernel="Gaussian",h=1,dt){
    v.names <- V(g)$name
    DistMat <- shortest.paths(g)
    KernelMat <- dnorm(DistMat,mean=0,sd=sqrt(h))
    n <- length(V(g))
    surv.obj <- Surv(time=dt$y,event=dt$delta)
    BetaMat <- NULL
    for(v in 1:n){
        beta <- sum(KernelMat[v,]*dt$delta)/sum(KernelMat[v,]*dt$y)
        BetaMat <- c(BetaMat,beta)
    }
    return(BetaMat)
}


newton.term <- function(eta,ties=TRUE,dt){
    e.eta <- exp(eta)
    dd <- table(dt$y[dt$delta==1])
    t.set <- as.numeric(names(dd))
    m <- length(t.set)
    t.e.eta.sum <- rep(0,m)
    for(i in 1:m){
        t.e.eta.sum[i] <- sum(e.eta[dt$y >= t.set[i]])
        #print(e.eta[dt$y >= t.set[i]])
    }
    n <- nrow(dt)
    result.h <- result.g <- rep(0,n)
    for(v in 1:n){
        hv <- sub.gradl <- 0
        for(i in which(t.set <= dt$y[v])){
            hv <- hv + dd[i]*(e.eta[v]*t.e.eta.sum[i] - e.eta[v]^2)/(t.e.eta.sum[i])^2
            sub.gradl <- sub.gradl + dd[i]*(e.eta[v])/t.e.eta.sum[i]
            #print(i)
            #print((e.eta[v]*t.e.eta.sum[i] - e.eta[v]^2)/(t.e.eta.sum[i])^2)
        }
        result.h[v] <- hv
        result.g[v] <- eta[v] + (dt$delta[v] - sub.gradl)/max(hv,0.00001)
        #print((t.e.eta.sum[i])^2)

    }
    if(sum(is.na(result.g))>0){
    	    print(e.eta)
        print(result.g)
        print("GGG")
        print(result.h)
        print("HHH")

    	    stop("NA produced!")
    }
    #print(e.eta)
    #print(result.g)
    #print("GGG")
    #print(result.h)
    #print("HHH")
    return(list(h.seq=result.h,g.seq=result.g))
}



get.pll <- function(dt,alpha,v=NULL,X=NULL,beta=NULL){
	n <- nrow(dt)
        lpl <- 0
 	e.alpha <- exp(alpha)
        if(is.null(v)){
                if(is.null(X)){
                	eta <- alpha
                	}else{
                		eta <- alpha + as.numeric(X%*%matrix(beta,ncol=1))
                	}
                e.eta <- exp(eta)
                dd <- table(dt$y[dt$delta==1])
                t.set <- as.numeric(names(dd))
                m <- length(t.set)
                t.e.eta.sum <- rep(0,m)
                D.set <- list()
                for(i in 1:m){
                    t.e.eta.sum[i] <- sum(e.eta[dt$y >= t.set[i]])
                    D.set[[i]] <- intersect(which(dt$y==t.set[i]),which(dt$delta==1))
                }
                lpl <- 0
                for(i in 1:m){
    	               lpl <- lpl + sum(eta[D.set[[i]]]) - dd[i]*log(t.e.eta.sum[i])
    	               #print(lpl)
                }

        }else{
        if(dt$delta[v]==1){
			if(is.null(X)){
				lpl <- alpha[v] - log(sum(e.alpha[dt$y>=dt$y[v]]))
			}else{
				lpl <- alpha[v]+sum(X[v,]*beta) - log(sum(exp(alpha+as.numeric(X%*%matrix(beta,ncol=1)))[dt$y>=dt$y[v]]))
				}
	}
        }
	return(lpl)
}



newton.term.simple <- function(eta,ties=TRUE,dt){
    ## use the notations and formualtion in Hastie & Tibshirani 1990 to write
    e.eta <- exp(eta)
    dd <- table(dt$y[dt$delta==1])
    t.set <- as.numeric(names(dd))
    m <- length(t.set)
    t.e.eta.sum <- rep(0,m)
    for(i in 1:m){
        t.e.eta.sum[i] <- sum(e.eta[dt$y >= t.set[i]])
    }
    n <- nrow(dt)
    result.h <- result.g <- rep(0,n)
    for(v in 1:n){

        sub.gradl <- exp(eta[v]+log(sum(exp(log(dd[which(t.set <= dt$y[v])])-log(t.e.eta.sum[which(t.set <= dt$y[v])])))))
        hv <- sub.gradl- exp(2*eta[v]+log(sum(exp(log(dd[which(t.set <= dt$y[v])])-2*log(t.e.eta.sum[which(t.set <= dt$y[v])])))))

        result.h[v] <- hv
        result.g[v] <- eta[v] + (dt$delta[v] - sub.gradl)/max(hv,0.00001)

    }
    if(sum(is.na(result.g))>0){
    	    print(e.eta)
        print(result.g)
        print("GGG")
        print(result.h)
        print("HHH")

    	    stop("NA produced!")
    }
    return(list(h.seq=result.h,g.seq=result.g))
}

get.new.alpha <- function(fuse.model,ne.set){
    if(length(ne.set)>0){
        return(mean(fuse.model$alpha[ne.set]))
    }
    return(0)
}





library(Matrix)

Cox.RNC <- function(A,lambda,dt,X=NULL,ties=TRUE,max.iter.outer=500,thr.outer=5e-6,init=NULL,theta=0.05,cv=NULL,normal=FALSE,cutoff=0.99,dev.stationary=500,cv.seed=999,test.X=NULL,complete.A=NULL,test.dt=NULL){
    print(paste("max iteration number:",max.iter.outer))
    n <- nrow(A)
    if(is.null(X)){
    	    p <- 0
    	}else{
    		p <- ncol(X)
    		}
    if(is.null(init)){

        alpha.null <- rep(0,n)
        beta.null <- rep(0,p)
        beta.tilde.null <- matrix(c(alpha.null,beta.null),ncol=1)
    }else{
        beta.tilde.null <- matrix(init,ncol=1)
    }

    X.tilde <- cbind(diag(rep(1,n)),X)
    iter.outer <- 0
    err.outer <- 100

    D <- diag(rowSums(A))
    L <- ((D - A) + theta*diag(rep(1,n)))
    if(normal){
        D.inverse.sqrt <- diag(1/rowSums(A))
        M.sub <- lambda*(D.inverse.sqrt%*%(D - A)%*%D.inverse.sqrt + theta*diag(rep(1,n)))
    }else{
        M.sub <- lambda*L
    }
    M <- matrix(0,nrow=n+p,ncol=n+p)
    M[1:n,1:n] <- M.sub
    l.null <- -2000000

    dev.cutoff <- 0.99
    if(!is.null(cutoff)){
        #print("model0")
        model0 <- Cox.RNC(A,lambda=10000000,dt=dt,ties=ties,max.iter.outer=max.iter.outer,thr.outer=thr.outer,theta=1,normal=normal,cutoff=NULL)
        print(model0$iter)
        l.null <- model0$lpl
        dev.cutoff <- cutoff
        print("finish model0")
    }
    dev.null <- 0-l.null
    dd <- table(dt$y[dt$delta==1])
    t.set <- as.numeric(names(dd))
    m <- length(t.set)
    dev.improve <- 0.1*dev.null
    dev.improve.old <- 0
    #print(paste("dev.null",dev.null))
    stat.num <- 0
    Singular.flag <- FALSE
    min.sv <- NULL
    eta.null <- X.tilde %*% beta.tilde.null

    while((iter.outer < max.iter.outer) && (err.outer > thr.outer) && (stat.num<dev.stationary) && (!Singular.flag)){
        iter.outer <- iter.outer + 1        
        if(ties){
            terms <- newton.term.simple(eta.null,ties=ties,dt)
            h.eta.null <- matrix(terms$h.seq,ncol=1)
            g.eta.null <- matrix(terms$g.seq,ncol=1)
        }
        beta.tilde <- beta.tilde.null
        iter.inner <- 1
        err.inner <- 100
        #print(h.eta.null)
        W <- diag(as.numeric(h.eta.null))
        middle.mat <- t(X.tilde)%*%W%*%X.tilde/n + M
        #print(min(svd(middle.mat)$d))
        sparse.model.mat <- Matrix(middle.mat,sparse=TRUE)
        M.mat <- solve(middle.mat,t(X.tilde)%*%W)/n
        #SVD.D.inv <- diag(1/SVD$d)
        #M.mat <- SVD$v %*% SVD.D.inv %*% t(SVD$u) %*% t(X.tilde)%*%W/n
        beta.tilde <- M.mat %*% g.eta.null
        
        err.outer <- sqrt(sum((beta.tilde.null - beta.tilde)^2))
        beta.tilde.null <- beta.tilde
        eta <- eta.null <- X.tilde %*% beta.tilde.null
        e.eta <- exp(eta)
        t.e.eta.sum <- rep(0,m)
        D.set <- list()
        for(i in 1:m){
            t.e.eta.sum[i] <- sum(e.eta[dt$y >= t.set[i]])
            D.set[[i]] <- intersect(which(dt$y==t.set[i]),which(dt$delta==1))
        }
        lpl <- 0
        for(i in 1:m){
               lpl <- lpl + sum(eta[D.set[[i]]]) - dd[i]*log(t.e.eta.sum[i])
        }
        if(lpl == -Inf) {
        warning("Blow up! Stop!")
        break}
        dev.improve <- lpl-l.null
        #print(lpl)
        if(abs(dev.improve-dev.improve.old)/abs(l.null)<1e-7){
            stat.num <- stat.num + 1
        }else{
            stat.num <- 0
        }
        dev.improve.old <- dev.improve

    }
    alpha <- beta.tilde[1:n]
    beta <- beta.tilde[-(1:n)]
    if(length(beta)==0) beta <- NULL
    W <- diag(as.numeric(h.eta.null))


    df <- sum(diag(X.tilde%*%M.mat))
    AIC <- lpl - df
    BIC <- lpl - 0.5*log(n)*df
    GCV <- -1*lpl/(n*(1-df/n)^2)
    LOO.cv <- 0
    SCV.lpl <- CV.lpl <- NULL
if(!is.null(cv)){
set.seed(cv.seed)
K <- cv
if(K<n){
dead.index <- which(dt$delta==1)
dead.cv.index <- sample(x=rep(1:K,ceiling(length(dead.index)/K))[1:length(dead.index)],size=length(dead.index))
censor.index <- which(dt$delta==0)
censor.cv.index <- sample(x=rep(1:K,ceiling(length(censor.index)/K))[1:length(censor.index)],size=length(censor.index))

cv.index <- rep(0,n)
cv.index[dead.index] <- dead.cv.index
cv.index[censor.index] <- censor.cv.index
}
if(K==n){
    cv.index <- 1:n
}

CV.lpl <- SCV.lpl <- 0
for(cv.k in 1:K){
        print(paste("LOO CV at iteration ",cv.k))
        valid.index <- which(cv.index==cv.k)
        print(valid.index)
	current.index <- seq(1,n)[-valid.index]
        s.A <- A[current.index,current.index]
	    s.dt <- dt[current.index,]
	    if(is.null(X)){
	    	    s.X <- NULL
	    }else{
	        s.X <- matrix(X[current.index,],ncol=p)
	        }
        tmp.init <- NULL
        if(!is.null(init)) {
        	    if(is.null(X)){
        	    	tmp.init <- init[c(current.index)]
        	    }else{
        	        tmp.init <- init[c(current.index,(n+1):(n+p))]
        	    }
        	}
        tmp.model <- Cox.RNC(A=s.A,lambda=lambda,dt=s.dt,X=s.X,max.iter.outer=max.iter.outer,theta=theta,init=tmp.init,ties=ties,thr.outer=thr.outer,dev.stationary=dev.stationary)
        print("CV model fitted!")
        L.valid <- Matrix(L[valid.index,valid.index],sparse=TRUE)
        
        valid.alpha <- -solve(L.valid,L[valid.index,current.index]%*%tmp.model$alpha)
#	for(v in valid.index){
#            v.adj <- A[v,-valid.index]
            
#	if(sum(v.adj)>1){
#                print("has neighbors")
#                v.alpha <- sum(tmp.model$alpha*v.adj)/(sum(v.adj)+theta)
#                print("Estimated alpha computed")
#                valid.alpha <- c(valid.alpha,v.alpha)
#            }else{
#                valid.alpha <- c(valid.alpha,0)
#            }
#        }
                new.alpha <- rep(0,n)
                new.alpha[current.index] <- tmp.model$alpha
                new.alpha[valid.index] <- as.numeric(valid.alpha)
        l.beta.k <- get.pll(dt,new.alpha,X=X,beta=tmp.model$beta)
        l.k.beta.k <- tmp.model$lpl
        CV.lpl <- CV.lpl + l.beta.k - l.k.beta.k
        SCV.lpl <- SCV.lpl + l.beta.k/(n*(1-tmp.model$df/n)^2) - l.k.beta.k/(nrow(s.dt)*(1-tmp.model$df/nrow(s.dt))^2)
    }

}

#### If a test.X is provided and the complete.A is available (first n are training nodes), then we can evaluate the deviance on the test set. Currently, only one test.X is implemented.

test.dev <- NULL
test.alpha <- NULL
test.lr <- NULL
if(!is.null(complete.A)){
	print("begin test")
	n.test <- nrow(complete.A) - n
	test.alpha <- rep(0,n.test)
        complete.D <- diag(colSums(complete.A))
        complete.L <- complete.D - complete.A + theta*diag(rep(1,nrow(complete.A)))
        test.alpha <- -solve(complete.L[(n+1):(n+n.test),(n+1):(n+n.test)],complete.L[(n+1):(n+n.test),1:n]%*%alpha)

	if(!is.null(X)){
	    test.l1 <- get.pll(dt=rbind(dt,test.dt),alpha=c(alpha,test.alpha),X=rbind(X,test.X),beta=beta)	
	    }else{
	    test.l1 <- get.pll(dt=rbind(dt,test.dt),alpha=c(alpha,test.alpha))	
	    }
	print(test.l1)
	test.l0 <- get.pll(dt=dt,alpha=alpha,X=X,beta=beta)
	print(test.l0)
	test.dev <- (test.l1-test.l0)
	if(!is.null(X)){
	   test.PI <- test.alpha + as.numeric(test.X%*%matrix(beta,ncol=1))
	}else{
		test.PI <- test.alpha
	}
	# p.group.test <- which(test.PI>=median(test.PI))
    # n.group.test <- which(test.PI<median(test.PI))
    # group.index <- rep(1,n.test)
    # group.index[n.group.test] <- 2
    # test.surv <- Surv(time=test.dt$y,event=test.dt$delta)
    # group.test <- survdiff(test.surv~group.index)
    #print("get log rank test")
    test.lr <- 0#1-pchisq(group.test$chisq,df=1)
}
    return(list(alpha=alpha,beta=beta,err=err.outer,iter=iter.outer,iter.inner = iter.inner,df=df,lpl = lpl,aic=AIC,bic=BIC,GCV=GCV,cv=CV.lpl,scv=SCV.lpl,dev.explain=dev.improve/dev.null,lambda=lambda,theta=theta,min.sv=min.sv,test.dev=test.dev,test.alpha=test.alpha,test.lr=test.lr,singular=Singular.flag))
}


